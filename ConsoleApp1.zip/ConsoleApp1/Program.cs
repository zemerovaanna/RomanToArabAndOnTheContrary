﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static int getArabian(char romanNumber)
        {
            if ('I' == romanNumber) return 1;
            else if ('V' == romanNumber) return 5;
            else if ('X' == romanNumber) return 10;
            else if ('L' == romanNumber) return 50;
            else if ('C' == romanNumber) return 100;
            else if ('D' == romanNumber) return 500;
            else if ('M' == romanNumber) return 1000;
            return 0;
        }

        static int romanToInt (string s)
        {
            int endArray = s.Length - 1;
            char[] charsArray = new char[Convert.ToByte(s.Length)];
            for (int i = 0; i < s.Length; i++)
            {
                charsArray[i] = s[i];
            }

            int arabian;
            int result = getArabian (charsArray[endArray]);

            for (int i = endArray - 1; i >= 0; i--)
            {
                arabian = getArabian(charsArray[i]);

                if (arabian < getArabian(charsArray[i + 1]))
                {
                    result -= arabian;
                }
                else
                {
                    result += arabian;
                }
            }

            return result;
        }



















        public static string ToRoman(int number)
        {
            if (number < 0 || number > 3999)
                throw new ArgumentException("Value must be in the range 0 - 3,999.");

            if (number == 0) return "N";

            int[] values = new int[] { 1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1 };
            string[] numerals = new string[]
            { "M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I" };


            StringBuilder result = new StringBuilder();


            for (int i = 0; i < 13; i++)
            {
                while (number >= values[i])
                {
                    number -= values[i];
                    result.Append(numerals[i]);
                }
            }

            return result.ToString();
        }

        static void Main(string[] args)
        {
            for (int i = 0; i < 4000; i++)
            {
                Console.WriteLine("---------------------------");
                Console.WriteLine(i);
                Console.WriteLine(ToRoman(i));
                Console.WriteLine(romanToInt(ToRoman(i)));
                Console.WriteLine("---------------------------");
            }
            Console.ReadKey();
        }
    }
}